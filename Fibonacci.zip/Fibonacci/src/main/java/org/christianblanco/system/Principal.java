
package org.christianblanco.system;
import java.util.Scanner;
/**
 *
 * @author Christian Fernando Blanco Morales
 * IN5BM / 2017162
 * 
 */
public class Principal {
   public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Christian Blanco");
        System.out.println("IN5BM / 2017162");
        System.out.println("");
        System.out.println("--------------MENU------------");
        System.out.println("1 - Convertir segundos ");
        System.out.println("2 - Cambio de billetes ");
        System.out.println("3 - Par o impar ");
        System.out.println("4 - Numero perfecto");
        System.out.println("5 - Serie de fibonacci");
        System.out.println(" Seleccione una opcion (1-5)");
         System.out.println("------------------------------");
        int opcion = teclado.nextInt();
        
        switch(opcion){
        case 1:
                  int horas;
                  int minutos;
                  int segundos;
                  
                  System.out.println("ingresa un numero");
                  int numUno = teclado.nextInt();
                  
                  horas = numUno / 3600;
                  minutos = numUno / 60;
                  segundos = numUno - minutos;
                  System.out.println(numUno + " equivale a: " + horas + " horas " + minutos + " minutos " + segundos + " segundos ");
                  break; 
                  
            case 2: 
                int doscientos;
                int cien;
                int cincuenta;
                int veinte;
                int diez;
                int cinco;
                int uno;
                int numDos;
                int residuo;
                int cantidad;
                
                System.out.println("ingrese un numero");
                 numDos = teclado.nextInt();
                
               if(numDos >= 1 && numDos<=1000000){
                   
                 doscientos = numDos / 200;
                 residuo = numDos % 200;
                 
                 cien = residuo / 100;
                 residuo = residuo % 100;
                 
                 cincuenta = residuo / 50;
                 residuo = residuo % 50;
                 
                 veinte = residuo / 20;
                 residuo = residuo % 20;
                 
                 diez = residuo / 10;
                 residuo = residuo % 10;
                 
                 cinco = residuo / 5;
                 residuo = residuo % 5;
                 
                 uno = residuo / 1;
                 
                 System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^");
                 System.out.println("Desglose de: " + numDos);
                 System.out.println(numDos + " En billetes de 200 es: " + doscientos);
                 System.out.println(numDos + " En billetes de 100 es: " + cien);
                 System.out.println(numDos + " En billetes de 50 es: " + cincuenta);
                 System.out.println(numDos + " En billetes de 20 es: " + veinte);
                 System.out.println(numDos + " En billetes de 10 es: " + diez);
                 System.out.println(numDos + " En billetes de 5 es: " + cinco);
                 System.out.println(numDos + " En billetes de 1 es: " + uno);
                 
               }else{
                System.out.println("Esa cantidad no esta disponible");
               }
              break;
              
            case 3:
                System.out.println(" Ingrese un numero ");
                int numTres = teclado.nextInt();
                
                if(numTres % 2 == 0){
                 System.out.println("");
                 System.out.println(" El numero ingresado es par ");
                }else{
                 System.out.println(" El numero ingresado es impar");
                }
                break;
                
            case 4: 
                System.out.println("ingrese un numero");
                int numCuatro = teclado.nextInt();
                int reserva = 0;
                
                for(int i=1; i<numCuatro; i++){
                 if( numCuatro % i == 0){
                  reserva = reserva + i;
                 }
                }
                 if(reserva == numCuatro){
                  System.out.println(" El numero es perfecto ");
                 }else{
                  System.out.println(" El numero no es perfecto");
                 }
               break;     
            case 5:
                
                int a = 0;
                int b = 1;
                int c;
                int n;       
                System.out.println("Ingrese un limite para la sucesion ");
                n = teclado.nextInt();
                System.out.println("------------------------------------ ");
                
                for(int i = 0; i < n; i++){
                   System.out.print(a + ",");
                  
                   c = a + b;
                   a = b;
                   b = c;
                }
             break;
       }
     }
   }       

