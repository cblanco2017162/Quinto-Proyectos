DROP DATABASE IF EXISTS control_academico;
CREATE DATABASE control_academico;
USE control_academico;

-- -----------------------------------------------------
-- Tabla Alumno
-- -----------------------------------------------------
DROP TABLE IF EXISTS alumno;
CREATE TABLE alumno(
	carne VARCHAR(16) NOT NULL,
    apellidos VARCHAR(45),
    nombres VARCHAR(45),
    email VARCHAR(32),
    PRIMARY KEY(carne)
);

-- -----------------------------------------------------
-- Tabla Horario
-- -----------------------------------------------------
DROP TABLE IF EXISTS horario;
CREATE TABLE IF NOT EXISTS horario(
 horario_id INT NOT NULL auto_increment,
 horario_final TIME NOT NULL,
 horario_inicio TIME NOT NULL,
 primary key (horario_id)
);
  
-- -----------------------------------------------------
-- Tabla Salon
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS salon (
  salon_id INT NOT NULL AUTO_INCREMENT,
  capacidad INT NOT NULL,
  descripcion VARCHAR(225),
  nombre_salon VARCHAR(225),
  PRIMARY KEY (salon_id)
  );
  
-- -----------------------------------------------------
-- Tabla Carrera
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS carrera_tecnica (
  codigo_carrera VARCHAR(128),
  nombre VARCHAR(45),
  PRIMARY KEY (codigo_carrera)
);

-- -----------------------------------------------------
-- Tabla Instructor
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS instructor (
  instructor_id INT NOT NULL AUTO_INCREMENT,
  apellidos VARCHAR(45),
  nombres VARCHAR(45),
  direccion VARCHAR(45),
  telefono VARCHAR(45),
  PRIMARY KEY (instructor_id)
  );
  
-- -----------------------------------------------------
-- Tabla Curso
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS curso (
 curso_id INT NOT NULL AUTO_INCREMENT,
 ciclo INT, 
 cupo_maximo INT,
 cupo_minimo INT,
 descripcion VARCHAR(255),
 codigo_carrera VARCHAR(128),
 horario_id INT NOT NULL,
 instructor_id INT NOT NULL,
 salon_id INT NOT NULL,
 PRIMARY KEY (curso_id),
 CONSTRAINT FK_Curso_codigo_carrera FOREIGN KEY (codigo_carrera)
 REFERENCES carrera_tecnica  (codigo_carrera)ON DELETE CASCADE ON UPDATE CASCADE,
 CONSTRAINT FK_Curso_horario_id FOREIGN KEY (horario_id)
 REFERENCES Horario (horario_id)ON DELETE CASCADE ON UPDATE CASCADE,
 CONSTRAINT FK_Curso_instructor_id FOREIGN KEY (instructor_id)
 REFERENCES instructor (instructor_id)ON DELETE CASCADE ON UPDATE CASCADE,
 CONSTRAINT FK_Curso_salon_id FOREIGN KEY (salon_id)
 REFERENCES salon (salon_id) ON DELETE CASCADE ON UPDATE CASCADE
);

-- -----------------------------------------------------
-- Tabla Asignación
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS asignacion_alumno (
 asignacion_id VARCHAR(45),
 carne VARCHAR(16),
 curso_id INT NOT NULL,
 fecha_asignacion TIMESTAMP NOT NULL,
 PRIMARY KEY (asignacion_id),
 CONSTRAINT FK_Asignacion_Alumno_carne FOREIGN KEY (carne)
 REFERENCES alumno (carne) ON DELETE CASCADE ON UPDATE CASCADE,
 CONSTRAINT FK_Asignacion_curso_id FOREIGN KEY (curso_id)
 REFERENCES curso (curso_id) ON DELETE CASCADE ON UPDATE CASCADE
);

-- USO DE TABLA USUARIO

-- -----------------------------------------------------
-- Tabla Usuario
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS Usuario (
user VARCHAR(25) NOT NULL,
pass VARCHAR(255) NOT NULL,
nombre VARCHAR(50),
PRIMARY KEY PK_Usuario(user)
);

-- -----------------------------------------------------
-- LOGIN
-- -----------------------------------------------------
DROP PROCEDURE IF EXISTS sp_BuscarUsuario;
DELIMITER $$
	CREATE PROCEDURE sp_BuscarUsuario(IN _user VARCHAR(50))
    BEGIN
		SELECT
        Usuario.user ,
        Usuario.pass, 
		Usuario.nombre
        FROM Usuario 
        WHERE user = _user;
	END $$
DELIMITER ;

-- -----------------------------------------------------
-- DATOS DE PRUEBA
-- -----------------------------------------------------
-- DATOS LOGIN
insert into Usuario(user,pass,nombre)values("root","admin","Javier Rivas");
insert into Usuario(user,pass,nombre)values("kinal","12345","Alejandro Garcia");
insert into Usuario(user,pass,nombre)values("dpinzon","2020030","Diego Pinzon");
insert into Usuario(user,pass,nombre)values("cblanco","2017162","Christian Blancoa");
insert into Usuario(user,pass,nombre)values("caceituno","2017478","Carlos Aceituno");
insert into Usuario(user,pass,nombre)values("rsoto","2017508","Rene Soto");
insert into Usuario(user,pass,nombre)values("jalvarado","2017518","Julio Alvarado");
insert into Usuario(user,pass,nombre)values("darevalo","2020048","David Estuardo");

SELECT * FROM Usuario;

-- ALUMNO
INSERT INTO alumno(carne, apellidos, nombres, email) 
values('2021029','Valdez','Karla','Kvaldez@gmail.com');
INSERT INTO alumno(carne, apellidos, nombres, email) 
values('2021035','Hernandez','Rosio','Rhernandez@gmail.com');
INSERT INTO alumno(carne, apellidos, nombres, email) 
values('2021420','Rosales','Maria','Mrosales@gmail.com');
INSERT INTO alumno(carne, apellidos, nombres, email) 
values('2021332','Cardenaz','Luis','Lcardenaz@gmail.com');
INSERT INTO alumno(carne, apellidos, nombres, email) 
values('2021569','Velasquez','Vettani','Vvelasquez@gmail.com');
INSERT INTO alumno(carne, apellidos, nombres, email) 
values('2021965','Rivas','Javier','Jrivas@gmail.com');
INSERT INTO alumno(carne, apellidos, nombres, email) 
values('2021785','Cifuentes','Fatima','Fcifuentes@gmail.com');
INSERT INTO alumno(carne, apellidos, nombres, email) 
values('2021452','Melgar','Melissa','Mmelgar@gmail.com');
INSERT INTO alumno(carne, apellidos, nombres, email) 
values('2021123','Aceituno','Carlos','Caceituno@gmail.com');
INSERT INTO alumno(carne, apellidos, nombres, email) 
values('2021357','Garcia','Alejandro','Agarcia@gmail.com');
SELECT * FROM alumno;

-- HORARIO
INSERT INTO Horario(horario_final, horario_inicio) VALUES ("14:00", "6:30");
INSERT INTO Horario(horario_final, horario_inicio) VALUES ("15:35", "7:30");
INSERT INTO Horario(horario_final, horario_inicio) VALUES ("13:00", "7:45");
INSERT INTO Horario(horario_final, horario_inicio) VALUES ("14:30", "7:00");
INSERT INTO Horario(horario_final, horario_inicio) VALUES ("12:45", "8:00");
INSERT INTO Horario(horario_final, horario_inicio) VALUES ("17:00", "7:45");
INSERT INTO Horario(horario_final, horario_inicio) VALUES ("14:05", "5:55");
INSERT INTO Horario(horario_final, horario_inicio) VALUES ("18:00", "13:00");
INSERT INTO Horario(horario_final, horario_inicio) VALUES ("13:20", "6:25");
INSERT INTO Horario(horario_final, horario_inicio) VALUES ("19:00", "9:00");
SELECT * FROM horario;

-- INSTRUCTOR
INSERT INTO Instructor(apellidos, nombres, direccion, telefono)
VALUES("Lopéz", "Jose", "9na calle 15-77, Zona 7, Ciudad de Guatemala", "65231258");
INSERT INTO Instructor(apellidos, nombres, direccion, telefono)
 VALUES("Morales", "Daniel", "Zona 3, Ciudad de Guatemala", "15995123");
INSERT INTO Instructor(apellidos, nombres, direccion, telefono)
VALUES("Vásquez", "Adolfo", "18 Calle 1-12, Zona 11, Guatemala", "78945632");
INSERT INTO Instructor(apellidos, nombres, direccion, telefono)
VALUES("Castillo", "Antonio", "11 Calle 1-20, Zona 10, Ciudad de Guatemala", "25859636");
INSERT INTO Instructor(apellidos, nombres, direccion, telefono)
VALUES("Reyes", "Luis", "Diagonal 1 10-26, Zona 5, Ciudad de Guatemala", "45689236");
INSERT INTO Instructor(apellidos, nombres, direccion, telefono)
VALUES("Cruz", "Alan", "7ma Calle 1-20, Zona 15, Ciudad de Guatemala", "32152189");
INSERT INTO Instructor(apellidos, nombres, direccion, telefono)
VALUES("Aguilar", "Juan", "Diagonal 1 10-26, Zona 5, Ciudad de Guatemala", "48969874");
INSERT INTO Instructor(apellidos, nombres, direccion, telefono)
VALUES("Sánchez", "Gonzalo", "3ra Avenida 8-05, Bosques de San Jose", "30369918");
INSERT INTO Instructor(apellidos, nombres, direccion, telefono)
VALUES("Herrera", "Andrés", "10ma calle 14-60, Zona 2, Ciudad de Guatemala", "47595856");
INSERT INTO Instructor(apellidos, nombres, direccion, telefono) 
VALUES("Chavez", "Marcos", "9na calle 15-77, Zona 7, Ciudad de Guatemala", "87196662");
SELECT * FROM instructor;

-- CARRERA TECNICA
INSERT INTO carrera_tecnica(codigo_carrera, nombre) VALUES ("INABM","Perito en informatica matutina");
INSERT INTO carrera_tecnica(codigo_carrera, nombre) VALUES ("DTABM","Dibujo tecnico matutina");
INSERT INTO carrera_tecnica(codigo_carrera, nombre) VALUES ("MDABM","Mecanica diesel matutina");
INSERT INTO carrera_tecnica(codigo_carrera, nombre) VALUES ("EIABM","Electricidad industrial matutina");
INSERT INTO carrera_tecnica(codigo_carrera, nombre) VALUES ("ELABM","Electronica matutina");
INSERT INTO carrera_tecnica(codigo_carrera, nombre) VALUES ("INABV"," Perito en informatica vespertina");
INSERT INTO carrera_tecnica(codigo_carrera, nombre) VALUES ("DTABV","Dibujo tecnico vespertina");
INSERT INTO carrera_tecnica(codigo_carrera, nombre) VALUES ("MDABV","Mecanica diesel vespertina");
INSERT INTO carrera_tecnica(codigo_carrera, nombre) VALUES ("EIABV","Electricidad industrial vespertina");
INSERT INTO carrera_tecnica(codigo_carrera, nombre) VALUES ("ELABV","Electronica vespertina");
SELECT * FROM carrera_tecnica;

-- SALON
INSERT INTO salon(capacidad,descripcion,nombre_salon)
VALUES("25","Taller","A35");
INSERT INTO salon(capacidad,descripcion,nombre_salon)
VALUES("32","Mecanica","C28");
INSERT INTO salon(capacidad,descripcion,nombre_salon)
VALUES("28","Dibujo","Z14");
INSERT INTO salon(capacidad,descripcion,nombre_salon)
VALUES("30","Quimica","U30");
INSERT INTO salon(capacidad,descripcion,nombre_salon)
VALUES("17","Arquitectura","T24");
INSERT INTO salon(capacidad,descripcion,nombre_salon)
VALUES("32","Medicina","E35");
INSERT INTO salon(capacidad,descripcion,nombre_salon)
VALUES("36","Robotica","F32");
INSERT INTO salon(capacidad,descripcion,nombre_salon)
VALUES("19","Electronica","H23");
INSERT INTO salon(capacidad,descripcion,nombre_salon)
VALUES("26","Contador","W14");
INSERT INTO salon(capacidad,descripcion,nombre_salon)
VALUES("24","Electricidad","P12");
SELECT * FROM salon;

-- CURSO
INSERT INTO curso (ciclo, cupo_maximo, cupo_minimo, descripcion,  codigo_carrera, horario_id, instructor_id, salon_id) 
VALUES (2019,375,001,"Enfoque en la informatica", "INABM",1,1,1);
INSERT INTO curso (ciclo, cupo_maximo, cupo_minimo, descripcion,  codigo_carrera, horario_id, instructor_id, salon_id) 
VALUES (2018,400,001,"Educacion dedicada en dibujo tecnico", "DTABM",2,2,2);
INSERT INTO curso (ciclo, cupo_maximo, cupo_minimo, descripcion,  codigo_carrera, horario_id, instructor_id, salon_id) 
VALUES (2020,292,001,"Eduacion en maquinaria automotriz", "MDABM",3,3,3);
INSERT INTO curso (ciclo, cupo_maximo, cupo_minimo, descripcion,  codigo_carrera, horario_id, instructor_id, salon_id) 
VALUES (2020,300,002,"Electricidad de caracter industrial", "EIABM",4,4,4);
INSERT INTO curso (ciclo, cupo_maximo, cupo_minimo, descripcion,  codigo_carrera, horario_id, instructor_id, salon_id) 
VALUES (2021,500,020,"Emprendimiento en la electronica", "ELABM",5,5,5);
INSERT INTO curso (ciclo, cupo_maximo, cupo_minimo, descripcion,  codigo_carrera, horario_id, instructor_id, salon_id) 
VALUES (2019,375,001,"Enfoque en la informatica", "INABV",6,6,6);
INSERT INTO curso (ciclo, cupo_maximo, cupo_minimo, descripcion,  codigo_carrera, horario_id, instructor_id, salon_id) 
VALUES (2018,400,001,"Educacion dedicada en dibujo tecnico", "DTABV",7,7,7);
INSERT INTO curso (ciclo, cupo_maximo, cupo_minimo, descripcion,  codigo_carrera, horario_id, instructor_id, salon_id) 
VALUES (2020,292,001,"Eduacion en maquinaria automotriz", "MDABV",8,8,8);
INSERT INTO curso (ciclo, cupo_maximo, cupo_minimo, descripcion,  codigo_carrera, horario_id, instructor_id, salon_id) 
VALUES (2020,300,002,"Electricidad de caracter industrial", "EIABV",9,9,9);
INSERT INTO curso (ciclo, cupo_maximo, cupo_minimo, descripcion,  codigo_carrera, horario_id, instructor_id, salon_id) 
VALUES (2021,500,020,"Emprendimiento en la electronica", "ELABV",10,10,10);
SELECT * FROM curso;

-- ASIGNACION
INSERT INTO asignacion_alumno(asignacion_id, carne, curso_id , fecha_asignacion) 
values("AA001",'2021029',1,"2021-09-09 14:00:00");
INSERT INTO asignacion_alumno(asignacion_id, carne, curso_id , fecha_asignacion) 
values("AA002",'2021035',4,"2021-8-5 15:00:00");
INSERT INTO asignacion_alumno(asignacion_id, carne, curso_id , fecha_asignacion) 
values("AA003",'2021420',5,"2021-10-6 17:00:00");
INSERT INTO asignacion_alumno(asignacion_id, carne, curso_id , fecha_asignacion) 
values("AA004",'2021332',10,"2021-1-15 6:00:00");
INSERT INTO asignacion_alumno(asignacion_id, carne, curso_id , fecha_asignacion) 
values("AA005",'2021569',6,"2021-11-4 8:00:00");
INSERT INTO asignacion_alumno(asignacion_id, carne, curso_id , fecha_asignacion) 
values("AA006",'2021965',7,"2021-7-5 9:00:00");
INSERT INTO asignacion_alumno(asignacion_id, carne, curso_id , fecha_asignacion) 
values("AA007",'2021785',9,"2021-5-3 14:00:00");
INSERT INTO asignacion_alumno(asignacion_id, carne, curso_id , fecha_asignacion) 
values("AA008",'2021452',3,"2021-9-25 7:00:00");
INSERT INTO asignacion_alumno(asignacion_id, carne, curso_id , fecha_asignacion) 
values("AA009",'2021123',2,"2021-6-3 16:00:00");
INSERT INTO asignacion_alumno(asignacion_id, carne, curso_id , fecha_asignacion) 
values("AA010",'2021357',10,"2021-4-4 17:00:00");
SELECT * FROM asignacion_alumno;