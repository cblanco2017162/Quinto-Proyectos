/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.in5bm.equipo1.models.dao;

import com.in5bm.equipo1.db.Conexion;
import com.in5bm.equipo1.models.domain.AsignacionAlumno;
import com.in5bm.equipo1.models.idao.IAsignacionAlumnoDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Alejandro Javier García García Codigo Tecnico: IN5BM date 29/08/2021
 * time 16:41:12
 */
public class AsignacionAlumnoDaoImpl implements IAsignacionAlumnoDao {


    private static final String SQL_SELECT = "SELECT asignacion_id, carne, curso_id, fecha_asignacion FROM asignacion_alumno";
    private static final String SQL_DELETE = "DELETE FROM asignacion_alumno WHERE asignacion_id = ?";
    private static final String SQL_INSERT = "INSERT INTO asignacion_alumno (asignacion_id, carne, curso_id, fecha_asignacion) VALUES(?, ?, ?, ?)";
    private static final String SQL_SELECT_BY_ID = "SELECT asignacion_id, carne, curso_id, fecha_asignacion FROM asignacion_alumno WHERE asignacion_id = ? ";
    private static final String SQL_UPDATE = "UPDATE asignacion_alumno SET carne = ?, curso_id = ?, fecha_asignacion = ? WHERE asignacion_id = ?";

    private Connection conn = null;
    private PreparedStatement pstmt = null;
    private ResultSet rs = null;
    private AsignacionAlumno asignacion = null;
    List<AsignacionAlumno> listaAsignacion = new ArrayList<>();

    @Override
    public List<AsignacionAlumno> listar() {
        try {
            conn = Conexion.getConnection();
            pstmt = conn.prepareStatement(SQL_SELECT);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                String asignacionId = rs.getString("asignacion_id");
                String carne = rs.getString("carne");
                int cursoId = rs.getInt("curso_id");
                Timestamp fechaAsignacion = rs.getTimestamp("fecha_asignacion");

                asignacion = new AsignacionAlumno(asignacionId, carne, cursoId, fechaAsignacion);
                listaAsignacion.add(asignacion);
            }
        } catch (SQLException e) {
            e.printStackTrace(System.out);
        } catch (Exception e) {
            e.printStackTrace(System.out);
        } finally {
            Conexion.close(rs);
            Conexion.close(pstmt);
            Conexion.close(conn);
        }
        return listaAsignacion;
    }

    @Override
    public AsignacionAlumno encontrar(AsignacionAlumno asignacionAlumno) {
        try {
            conn = Conexion.getConnection();
            pstmt = conn.prepareStatement(SQL_SELECT_BY_ID);
            pstmt.setString(1, asignacionAlumno.getAsignacionId());
            rs = pstmt.executeQuery();

            while (rs.next()) {
                String asignacionId = rs.getString("asignacion_id");
                String carne = rs.getString("carne");
                int cursoId = rs.getInt("curso_id");
                Timestamp fechaAsignacion = rs.getTimestamp("fecha_asignacion");

                asignacionAlumno.setCarne(carne);
                asignacionAlumno.setCursoId(cursoId);
                asignacionAlumno.setFechaAsignacion(fechaAsignacion);

            }
        } catch (SQLException e) {
            e.printStackTrace(System.out);
        } catch (Exception e) {
            e.printStackTrace(System.out);
        } finally {
            Conexion.close(rs);
            Conexion.close(pstmt);
            Conexion.close(conn);
        }
        return asignacionAlumno;
    }

    @Override
    public int insertar(AsignacionAlumno asignacionAlumno) {
        int rows = 0;

        try {
            conn = Conexion.getConnection();
            pstmt = conn.prepareStatement(SQL_INSERT);
            pstmt.setString(1, asignacionAlumno.getAsignacionId());
            pstmt.setString(2, asignacionAlumno.getCarne());
            pstmt.setInt(3, asignacionAlumno.getCursoId());
            pstmt.setTimestamp(4, asignacionAlumno.getFechaAsignacion());

            rows = pstmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace(System.out);
        } catch (Exception e) {
            e.printStackTrace(System.out);
        } finally {
            Conexion.close(pstmt);
            Conexion.close(conn);
        }
        return rows;
    }

    @Override
    public int actualizar(AsignacionAlumno asignacionAlumno) {
        int rows = 0;
        try {
            conn = Conexion.getConnection();
            pstmt = conn.prepareStatement(SQL_UPDATE);
            pstmt.setString(1, asignacionAlumno.getCarne());
            pstmt.setInt(2, asignacionAlumno.getCursoId());
            pstmt.setTimestamp(3, asignacionAlumno.getFechaAsignacion());
            pstmt.setString(4, asignacionAlumno.getAsignacionId());
            System.out.println(pstmt.toString());
            rows = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(System.out);
        } finally {
            Conexion.close(pstmt);
            Conexion.close(conn);
        }
        return rows;
    }

    @Override
    public int eliminar(AsignacionAlumno asignacionAlumno) {
        int rows = 0;
        try {
            conn = Conexion.getConnection();
            pstmt = conn.prepareStatement(SQL_DELETE);
            pstmt.setString(1, asignacionAlumno.getAsignacionId());
            System.out.println(pstmt.toString());
            rows = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(System.out);
        } finally {
            Conexion.close(pstmt);
            Conexion.close(conn);
        }
        return rows;
    }
}
