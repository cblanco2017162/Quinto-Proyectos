package com.in5bm.equipo1.models.idao;

import com.in5bm.equipo1.models.domain.Horario;
import java.util.List;

/**
 *
 * @author garci
 */
public interface IHorarioDao {

    public List<Horario> listar();

    public Horario encontrar(Horario horario);

    public int insertar(Horario horario);

    public int actualizar(Horario horario);

    public int eliminar(Horario horario);
}