/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.in5bm.equipo1.controllers;

import com.in5bm.equipo1.models.dao.InstructorDaoImpl;
import com.in5bm.equipo1.models.domain.Instructor;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Alejandro Javier García García Codigo Tecnico: IN5BM date 29/08/2021
 * time 16:37:40
 */
@WebServlet("/ServletInstructorController")
public class ServletInstructorController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

        String accion = request.getParameter("accion");

        if (accion != null) {
            switch (accion) {
                case "listar":
                    listarInstructor(request, response);
                    break;
                case "editar":
                    editarInstructor(request, response);
                    break;
                case "eliminar":
                    eliminarInstructor(request, response);
                    break;
            }
        }

    }

    private void editarInstructor(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

        int instructorId = Integer.parseInt(request.getParameter("instructorId"));
        Instructor instructor = new InstructorDaoImpl().encontrar(new Instructor(instructorId));

        request.setAttribute("instructor", instructor);
        request.getRequestDispatcher("instructor/editar-instructor.jsp").forward(request, response);
    }

    private void eliminarInstructor(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int instructorId = Integer.parseInt(request.getParameter("instructorId"));

        Instructor instructor = new Instructor(instructorId);

        int registrosEliminados = new InstructorDaoImpl().eliminar(instructor);

        System.out.println("Cantidad de registros eliminados: " + registrosEliminados);

        listarInstructor(request, response);
    }

    private void listarInstructor(HttpServletRequest request, HttpServletResponse response) throws IOException {
        List<Instructor> listaInstructor = new InstructorDaoImpl().listar();

        HttpSession sesion = request.getSession();
        sesion.setAttribute("listadoInstructor", listaInstructor);
        sesion.setAttribute("numInstructores", listaInstructor.size());
        response.sendRedirect("instructor/instructor.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        request.setCharacterEncoding("UTF-8");
        System.out.println("ESTOT EN EL METODO DO POST");
        String accion = request.getParameter("accion");
        if (accion != null) {
            switch (accion) {
                case "insertar":
                    insertarInstructor(request, response);
                    break;
                case "actualizar":
                    actualizarInstructor(request, response);
                    break;
            }
        }
    }

    private void insertarInstructor(HttpServletRequest request, HttpServletResponse response) throws IOException {
        if (request.getParameter("apellidos").equals("") || request.getParameter("nombres").equals("") || request.getParameter("direccion").equals("")
                || request.getParameter("telefono").equals("")) {
            System.out.println("Campos Vacios");

        } else {
            String apellidos = request.getParameter("apellidos");
            String nombres = request.getParameter("nombres");
            String direccion = request.getParameter("direccion");
            String telefono = request.getParameter("telefono");

            Instructor instructor = new Instructor(apellidos, nombres, direccion, telefono);
            System.out.println(instructor);

            int registrosInsertados = new InstructorDaoImpl().insertar(instructor);
            System.out.println("Registros Insertados: " + registrosInsertados);
        }
        listarInstructor(request, response);
    }

    private void actualizarInstructor(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int instructorId = Integer.parseInt(request.getParameter("instructorId"));
        String apellidos = request.getParameter("apellidos");
        String nombres = request.getParameter("nombres");
        String direccion = request.getParameter("direccion");
        String telefono = request.getParameter("telefono");

        Instructor instructor = new Instructor(instructorId, apellidos, nombres, direccion, telefono);
        System.out.println(instructor);

        int registrosModificados = new InstructorDaoImpl().actualizar(instructor);
        System.out.println("Registros Modificados: " + registrosModificados);

        listarInstructor(request, response);
    }

}
