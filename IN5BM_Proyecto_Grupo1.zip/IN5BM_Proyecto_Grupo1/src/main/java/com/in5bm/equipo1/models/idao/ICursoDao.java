package com.in5bm.equipo1.models.idao;

import com.in5bm.equipo1.models.domain.Curso;
import java.util.List;

/**
 *
 * @author garci
 */
public interface ICursoDao {

    public List<Curso> listar();

    public Curso encontrar(Curso curso);

    public int insertar(Curso curso);

    public int actualizar(Curso curso);

    public int eliminar(Curso curso);
}