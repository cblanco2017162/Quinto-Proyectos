package com.in5bm.equipo1.models.idao;

import com.in5bm.equipo1.models.domain.AsignacionAlumno;
import java.util.List;

/**
 *
 * @author garci
 */

public interface IAsignacionAlumnoDao {

    public List<AsignacionAlumno> listar();

    public AsignacionAlumno encontrar(AsignacionAlumno asignacionAlumno);

    public int insertar(AsignacionAlumno asignacionAlumno);

    public int actualizar(AsignacionAlumno asignacionAlumno);

    public int eliminar(AsignacionAlumno asignacionAlumno);
}