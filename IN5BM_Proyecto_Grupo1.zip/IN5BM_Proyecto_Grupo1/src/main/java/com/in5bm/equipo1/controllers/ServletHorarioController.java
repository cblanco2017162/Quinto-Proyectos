/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.in5bm.equipo1.controllers;

import java.io.IOException;
import java.util.List;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest; //perticiones que son realizadas
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.annotation.WebServlet;
import javax.servlet.ServletException;

import com.in5bm.equipo1.models.dao.HorarioDaoImpl;
import com.in5bm.equipo1.models.domain.Horario;
import java.sql.Time;

/**
 *
 * @author Alejandro Javier García García Codigo Tecnico: IN5BM date 29/08/2021
 * time 16:37:40
 */
@WebServlet("/ServletHorarioController")
public class ServletHorarioController extends HttpServlet {

    private static final String JSP_LISTAR = "horario/horario.jsp";
    private static final String JSP_EDITAR = "horario/editar-horario.jsp";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        String accion = request.getParameter("accion");
        if (accion != null) {
            switch (accion) {
                case "listar":
                    listarHorario(request, response);
                    break;
                case "editar":
                    editarHorario(request, response);
                    break;
                case "eliminar":
                    eliminarHorario(request, response);
                    break;
            }
        }
    }

    private void listarHorario(HttpServletRequest request, HttpServletResponse response) throws IOException {
        List<Horario> listaHorario = new HorarioDaoImpl().listar();
        HttpSession sesion = request.getSession();
        sesion.setAttribute("listadoHorario", listaHorario);
        sesion.setAttribute("numHorarios", listaHorario.size());

        response.sendRedirect(JSP_LISTAR);
    }

    private void eliminarHorario(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int horarioId = Integer.parseInt(request.getParameter("horarioId"));
        Horario horario = new Horario(horarioId);
        int registrosEliminados = new HorarioDaoImpl().eliminar(horario);
        System.out.println("cantidad de registros eliminados:" + registrosEliminados);
        listarHorario(request, response);
    }

    private void editarHorario(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int horarioId = Integer.parseInt(request.getParameter("horarioId"));

        Horario horario = new HorarioDaoImpl().encontrar(new Horario(horarioId));

        request.setAttribute("horario", horario);

        request.getRequestDispatcher(JSP_EDITAR).forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String accion = request.getParameter("accion");

        if (accion != null) {
            switch (accion) {

                case "insertar":
                    insertarHorario(request, response);
                    break;
                case "actualizar":
                    actualizarHorario(request, response);
                    break;
            }
        }
    }

    private void insertarHorario(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Time horarioFinal = Time.valueOf(request.getParameter("horarioFinal"));
        Time horarioInicio = Time.valueOf(request.getParameter("horarioInicio"));

        Horario horario = new Horario(horarioFinal, horarioInicio);
        System.out.println(horario);

        int registrosInsertados = new HorarioDaoImpl().insertar(horario);
        System.out.println("Registros insertados: " + registrosInsertados);

        listarHorario(request, response);
    }

    private void actualizarHorario(HttpServletRequest request, HttpServletResponse response) throws IOException {

        int horarioId = Integer.parseInt(request.getParameter("horarioId"));
        Time horarioFinal = Time.valueOf(request.getParameter("horarioFinal"));
        Time horarioInicio = Time.valueOf(request.getParameter("horarioInicio"));

        Horario horario = new Horario(horarioId, horarioFinal, horarioInicio);

        int registrosModificados = new HorarioDaoImpl().actualizar(horario);
        System.out.println("Registros Modificados: " + registrosModificados);

        listarHorario(request, response);
    }
}
