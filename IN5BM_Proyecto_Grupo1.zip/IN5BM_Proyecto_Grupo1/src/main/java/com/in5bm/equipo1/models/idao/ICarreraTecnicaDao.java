package com.in5bm.equipo1.models.idao;

import com.in5bm.equipo1.models.domain.CarreraTecnica;
import java.util.List;

/**
 *
 * @author garci
 */
public interface ICarreraTecnicaDao {

    public List<CarreraTecnica> listar();

    public CarreraTecnica encontrar(CarreraTecnica carreraTecnica);

    public int insertar(CarreraTecnica carreraTecnica);

    public int actualizar(CarreraTecnica carreraTecnica);

    public int eliminar(CarreraTecnica carreraTecnica);
}