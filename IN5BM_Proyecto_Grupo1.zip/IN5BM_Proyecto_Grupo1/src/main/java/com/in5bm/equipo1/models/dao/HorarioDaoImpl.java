/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.in5bm.equipo1.models.dao;

import com.in5bm.equipo1.db.Conexion;
import com.in5bm.equipo1.models.domain.Horario;
import com.in5bm.equipo1.models.idao.IHorarioDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Alejandro Javier García García Codigo Tecnico: IN5BM date 29/08/2021
 * time 16:41:12
 */
public class HorarioDaoImpl implements IHorarioDao {

    private static final String SQL_SELECT = "SELECT horario_id, horario_final, horario_inicio FROM horario";
    private static final String SQL_DELETE = "DELETE FROM horario WHERE horario_id = ?";
    private static final String SQL_SELECT_ID = "SELECT horario_id, horario_final, horario_inicio FROM horario WHERE horario_id = ?";
    private static final String SQL_INSERT = "INSERT INTO horario (horario_final, horario_inicio) VALUES (?, ?)";
    private static final String SQL_UPDATE = "UPDATE horario SET horario_final = ?, horario_inicio = ?  WHERE horario_id = ?";

    private Connection conn = null;
    private PreparedStatement pstmt = null;
    private ResultSet rs = null;
    private Horario horario = null;
    List<Horario> listaHorario = new ArrayList<>();

    @Override
    public List<Horario> listar() {
        try {
            conn = Conexion.getConnection();
            pstmt = conn.prepareStatement(SQL_SELECT);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                int horarioId = rs.getInt("horario_id");
                Time horarioFinal = rs.getTime("horario_final");
                Time horarioInicio = rs.getTime("horario_inicio");

                horario = new Horario(horarioId, horarioFinal, horarioInicio);
                listaHorario.add(horario);
            }
        } catch (SQLException e) {
            e.printStackTrace(System.err);
        } catch (Exception e) {
            e.printStackTrace(System.err);
        } finally {
            Conexion.close(rs);
            Conexion.close(pstmt);
            Conexion.close(conn);
        }
        return listaHorario;
    }

    @Override
    public Horario encontrar(Horario horario) {
        try {
            conn = Conexion.getConnection();
            pstmt = conn.prepareStatement(SQL_SELECT_ID);
            pstmt.setInt(1, horario.getHorarioId());
            rs = pstmt.executeQuery();
            while (rs.next()) {
                int idHorario = rs.getInt("horario_id");
                Time horarioFinal = rs.getTime("horario_final");
                Time horarioInicio = rs.getTime("horario_inicio");

                horario.setHorarioFinal(horarioFinal);
                horario.setHorarioInicio(horarioInicio);
            }

        } catch (SQLException e) {
            e.printStackTrace(System.out);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            Conexion.close(rs);
            Conexion.close(pstmt);
            Conexion.close(conn);
        }
        return horario;
    }

    @Override
    public int insertar(Horario horario) {
        int rows = 0;
        try {
            conn = Conexion.getConnection();
            pstmt = conn.prepareStatement(SQL_INSERT);
            pstmt.setTime(1, horario.getHorarioFinal());
            pstmt.setTime(2, horario.getHorarioInicio());
            System.out.println(pstmt.toString());

            rows = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(System.out);
        } catch (Exception e) {
            e.printStackTrace(System.out);
        } finally {
            Conexion.close(pstmt);
            Conexion.close(conn);
        }
        return rows;
    }

    @Override
    public int actualizar(Horario horario) {
        int rows = 0;
        try {
            conn = Conexion.getConnection();
            pstmt = conn.prepareStatement(SQL_UPDATE);
            pstmt.setTime(1, horario.getHorarioFinal());
            pstmt.setTime(2, horario.getHorarioInicio());
            pstmt.setDouble(3, horario.getHorarioId());
            System.out.println(pstmt.toString());

            rows = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            Conexion.close(pstmt);
            Conexion.close(conn);
        }
        return rows;
    }

    @Override
    public int eliminar(Horario horario) {
        int rows = 0;
        try {
            conn = Conexion.getConnection();
            pstmt = conn.prepareCall(SQL_DELETE);
            pstmt.setInt(1, horario.getHorarioId());
            rows = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(System.err);
        } catch (Exception e) {
            e.printStackTrace(System.err);
        } finally {
            Conexion.close(pstmt);
            Conexion.close(conn);
        }
        return rows;
    }

}
