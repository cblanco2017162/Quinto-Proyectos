/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.in5bm.equipo1.controllers;

import java.io.IOException;
import java.util.List;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.annotation.WebServlet;
import javax.servlet.ServletException;

import com.in5bm.equipo1.models.domain.Alumno;
import com.in5bm.equipo1.models.dao.AlumnoDaoImpl;

/**
 *
 * @author Alejandro Javier García García Codigo Tecnico: IN5BM date 29/08/2021
 * time 16:37:40
 */
@WebServlet("/ServletAlumnoController")
public class ServletAlumnoController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

        String accion = request.getParameter("accion");

        if (accion != null) {
            switch (accion) {
                case "listar":
                    listarAlumno(request, response);
                    break;
                case "editar":
                    editarAlumno(request, response);
                    break;
                case "eliminar":
                    eliminarAlumnoTecnica(request, response);
                    break;
            }
        }
    }

    private void editarAlumno(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

        String alumnoId = request.getParameter("alumnoId");
        Alumno alumno = new AlumnoDaoImpl().encontrar(new Alumno(alumnoId));

        request.setAttribute("alumno", alumno);
        request.getRequestDispatcher("alumno/editar-alumno.jsp").forward(request, response);
    }

    private void eliminarAlumnoTecnica(HttpServletRequest request, HttpServletResponse response) throws IOException {

        String alumnoId = request.getParameter("alumnoId");

        Alumno alumno = new Alumno(alumnoId);

        int registrosEliminados = new AlumnoDaoImpl().eliminar(alumno);

        System.out.println("Cantidad de registros eliminados: " + registrosEliminados);

        listarAlumno(request, response);
    }

    private void listarAlumno(HttpServletRequest request, HttpServletResponse response) throws IOException {
        List<Alumno> listaAlumno = new AlumnoDaoImpl().listar();

        HttpSession sesion = request.getSession();
        sesion.setAttribute("listadoAlumno", listaAlumno);
        sesion.setAttribute("numAlumnos", listaAlumno.size());
        response.sendRedirect("alumno/alumno.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        request.setCharacterEncoding("UTF-8");
        System.out.println("ESTOT EN EL METODO DO POST");
        String accion = request.getParameter("accion");
        if (accion != null) {
            switch (accion) {
                case "insertar":
                    insertarAlumno(request, response);
                    break;
                case "actualizar":
                    actualizarAlumno(request, response);
                    break;
            }
        }
    }

    private void insertarAlumno(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String alumnoId = request.getParameter("alumnoId");
        String apellidos = request.getParameter("apellidos");
        String nombres = request.getParameter("nombres");
        String email = request.getParameter("email");

        Alumno alumno = new Alumno(alumnoId, apellidos, nombres, email);
        System.out.println(alumno);

        int registrosInsertados = new AlumnoDaoImpl().insertar(alumno);
        System.out.println("Registros Insertados: " + registrosInsertados);

        listarAlumno(request, response);
    }

    private void actualizarAlumno(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String alumnoId = request.getParameter("alumnoId");
        String apellidos = request.getParameter("apellidos");
        String nombres = request.getParameter("nombres");
        String email = request.getParameter("email");

        Alumno alumno = new Alumno(alumnoId, apellidos, nombres, email);
        System.out.println(alumno);

        int registrosModificados = new AlumnoDaoImpl().actualizar(alumno);
        System.out.println("Registros Modificados: " + registrosModificados);

        listarAlumno(request, response);
    }

}
