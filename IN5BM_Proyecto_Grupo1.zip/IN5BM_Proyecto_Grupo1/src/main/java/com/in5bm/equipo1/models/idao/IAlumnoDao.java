package com.in5bm.equipo1.models.idao;

import com.in5bm.equipo1.models.domain.Alumno;
import java.util.List;

/**
 *
 * @author garci
 */
public interface IAlumnoDao {

    public List<Alumno> listar();

    public Alumno encontrar(Alumno alumno);

    public int insertar(Alumno alumno);

    public int actualizar(Alumno alumno);

    public int eliminar(Alumno alumno);
}