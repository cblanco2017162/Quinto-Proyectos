/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.in5bm.equipo1.controllers;

import java.io.IOException;
import java.util.List;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.annotation.WebServlet;

import com.in5bm.equipo1.models.domain.Salon;
import com.in5bm.equipo1.models.dao.SalonDaoImpl;
import javax.servlet.ServletException;

/**
 *
 * @author Alejandro Javier García García Codigo Tecnico: IN5BM date 29/08/2021
 * time 16:37:40
 */
@WebServlet("/ServletSalonController")
public class ServletSalonController extends HttpServlet {

    private static final String JSP_LISTAR = "salon/salon.jsp";
    private static final String JSP_EDITAR = "salon/editar-salon.jsp";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        String accion = request.getParameter("accion");
        if (accion != null) {
            switch (accion) {
                case "listar":
                    listarSalon(request, response);
                    break;
                case "editar":
                    editarSalon(request, response);
                    break;
                case "eliminar":
                    eliminarSalon(request, response);
                    break;
            }
        }

    }

    private void editarSalon(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

        int salonId = Integer.parseInt(request.getParameter("salonId"));
        Salon salon = new SalonDaoImpl().encontrar(new Salon(salonId));

        request.setAttribute("salon", salon);
        request.getRequestDispatcher(JSP_EDITAR).forward(request, response);
    }

    private void eliminarSalon(HttpServletRequest request, HttpServletResponse response) throws IOException {

        int salonId = Integer.parseInt(request.getParameter("salonId"));

        Salon salon = new Salon(salonId);

        int registrosEliminados = new SalonDaoImpl().eliminar(salon);

        System.out.println("Cantidad de registros eliminados: " + registrosEliminados);

        listarSalon(request, response);
    }

    private void listarSalon(HttpServletRequest request, HttpServletResponse response) throws IOException {
        List<Salon> listaSalon = new SalonDaoImpl().listar();

        HttpSession sesion = request.getSession();
        sesion.setAttribute("listadoSalon", listaSalon);
        sesion.setAttribute("numSalones", listaSalon.size());
        response.sendRedirect(JSP_LISTAR);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        request.setCharacterEncoding("UTF-8");
        System.out.println("Estoy dentro de post");

        String accion = request.getParameter("accion");
        if (accion != null) {
            switch (accion) {
                case "insertar":
                    insertarSalon(request, response);
                    break;

                case "actualizar":
                    actualizarSalon(request, response);
                    break;
            }
        }
    }

    private void insertarSalon(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            System.out.println("\ninsertarSalon");
            int capacidad = Integer.parseInt(request.getParameter("capacidad"));
            String descripcion = request.getParameter("descripcion");
            String nombreSalon = request.getParameter("nombreSalon");

            Salon salon = new Salon(capacidad, descripcion, nombreSalon);

            int registrosInsertados = new SalonDaoImpl().insertar(salon);
            System.out.println("registro salon " + registrosInsertados);
        } catch (Exception e) {
            System.out.println("Campos Vacíos");
        }
        listarSalon(request, response);
    }

    private void actualizarSalon(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int salonId = Integer.parseInt(request.getParameter("salonId"));

        int capacidad = Integer.parseInt(request.getParameter("capacidad"));
        String descripcion = request.getParameter("descripcion");
        String nombreSalon = request.getParameter("nombreSalon");

        Salon salon = new Salon(salonId, capacidad, descripcion, nombreSalon);

        int regitrosModificados = new SalonDaoImpl().actualizar(salon);
        System.out.println("Registros Modificados: " + regitrosModificados);

        listarSalon(request, response);
    }
}
