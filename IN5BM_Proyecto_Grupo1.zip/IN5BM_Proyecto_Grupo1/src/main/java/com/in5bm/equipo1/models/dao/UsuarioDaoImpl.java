/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.in5bm.equipo1.models.dao;

import com.in5bm.equipo1.db.Conexion;
import com.in5bm.equipo1.models.domain.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Alejandro Javier García García Codigo Tecnico: IN5BM date 29/08/2021
 * time 16:41:12
 */
public class UsuarioDaoImpl {

    private static final String SQL_SELECT_BY_ID = "SELECT * FROM Usuario WHERE user = ? AND pass = ? ";

    private Connection conn = null;
    private PreparedStatement pstmt = null;
    private ResultSet rs = null;

    public Usuario validar(String user, String pass) {
        Usuario usuario = new Usuario();

        try {
            conn = Conexion.getConnection();
            pstmt = conn.prepareStatement(SQL_SELECT_BY_ID);
            pstmt.setString(1, user);
            pstmt.setString(2, pass);

            rs = pstmt.executeQuery();

            while (rs.next()) {
                usuario.setUser(rs.getString("user"));
                usuario.setPass(rs.getString("pass"));
                usuario.setNombre(rs.getString("nombre"));
                
                System.out.println(user);
            }
        } catch (SQLException e) {
            e.printStackTrace(System.out);
        } catch (Exception e) {
            e.printStackTrace(System.out);
        } finally {
            Conexion.close(rs);
            Conexion.close(pstmt);
            Conexion.close(conn);
        }
        return usuario;
    }

}
