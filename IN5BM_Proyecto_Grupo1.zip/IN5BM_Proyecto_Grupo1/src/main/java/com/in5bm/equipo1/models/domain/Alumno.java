/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.in5bm.equipo1.models.domain;

/**
 *
 * @author Alejandro Javier García García Codigo Tecnico: IN5BM date 29/08/2021
 * time 16:44:43
 */
public class Alumno {

    private String alumnoId;
    private String apellidos;
    private String nombres;
    private String email;

    public Alumno() {
    }

    public Alumno(String alumnoId) {
        this.alumnoId = alumnoId;
    }

    public Alumno(String apellidos, String nombres, String email) {
        this.apellidos = apellidos;
        this.nombres = nombres;
        this.email = email;
    }

    public Alumno(String alumnoId, String apellidos, String nombres, String email) {
        this.alumnoId = alumnoId;
        this.apellidos = apellidos;
        this.nombres = nombres;
        this.email = email;
    }

    public String getAlumnoId() {
        return alumnoId;
    }

    public void setAlumnoId(String alumnoId) {
        this.alumnoId = alumnoId;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return "Alumno{" + "carne=" + alumnoId + ", apellidos=" + apellidos + ", nombres=" + nombres + ", email=" + email + '}';
    }

}
