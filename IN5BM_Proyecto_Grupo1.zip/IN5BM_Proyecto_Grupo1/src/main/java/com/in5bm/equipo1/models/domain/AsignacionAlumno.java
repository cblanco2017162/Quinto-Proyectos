/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.in5bm.equipo1.models.domain;
import java.sql.Timestamp;

/**
 *
 * @author Alejandro Javier García García Codigo Tecnico: IN5BM date 29/08/2021
 * time 16:44:43
 */
public class AsignacionAlumno {

    private String asignacionId;
    private String carne;
    private int cursoId;
    private Timestamp fechaAsignacion;

    public AsignacionAlumno() { }

    public AsignacionAlumno(String asignacionId, String carne, int cursoId, Timestamp fechaAsignacion) {
        this.asignacionId = asignacionId;
        this.carne = carne;
        this.cursoId = cursoId;
        this.fechaAsignacion = fechaAsignacion;
    }
    
     public AsignacionAlumno( String carne, int cursoId, Timestamp fechaAsignacion) {
        this.carne = carne;
        this.cursoId = cursoId;
        this.fechaAsignacion = fechaAsignacion;
    }

    public AsignacionAlumno(String asignacionId) {
        this.asignacionId = asignacionId;
    }

    public String getAsignacionId() {
        return asignacionId;
    }

    public void setAsignacionId(String asignacionId) {
        this.asignacionId = asignacionId;
    }

    public String getCarne() {
        return carne;
    }

    public void setCarne(String carne) {
        this.carne = carne;
    }

    public int getCursoId() {
        return cursoId;
    }

    public void setCursoId(int cursoId) {
        this.cursoId = cursoId;
    }

    public Timestamp getFechaAsignacion() {
        return fechaAsignacion;
    }

    public void setFechaAsignacion(Timestamp fechaAsignacion) {
        this.fechaAsignacion = fechaAsignacion;
    }

    @Override
    public String toString() {
        return "AsignacionAlumno{" + "asignacionId=" + asignacionId + ", carne=" + carne + ", cursoId=" + cursoId + ", fechaAsignacion=" + fechaAsignacion + '}';
    }

    
}
