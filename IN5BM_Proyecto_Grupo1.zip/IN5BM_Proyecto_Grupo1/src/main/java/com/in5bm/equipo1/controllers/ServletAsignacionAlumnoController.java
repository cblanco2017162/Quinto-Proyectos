/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.in5bm.equipo1.controllers;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.annotation.WebServlet;
import javax.servlet.ServletException;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.List;

import com.in5bm.equipo1.models.dao.AsignacionAlumnoDaoImpl;
import com.in5bm.equipo1.models.domain.AsignacionAlumno;

/**
 *
 * @author Alejandro Javier García García Codigo Tecnico: IN5BM date 29/08/2021
 * time 16:37:40
 */
@WebServlet("/ServletAsignacionAlumnoController")
public class ServletAsignacionAlumnoController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        String accion = request.getParameter("accion");

        if (accion != null) {
            switch (accion) {
                case "listar":
                    listarAsignacion(request, response);
                    break;
                case "editar":
                    editarAsignacion(request, response);
                    break;
                case "eliminar":
                    eliminarAsignacion(request, response);
                    break;
            }
        }
    }

    private void editarAsignacion(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

        String asignacionId = request.getParameter("asignacionId");
        AsignacionAlumno asignacionAlumno = new AsignacionAlumnoDaoImpl().encontrar(new AsignacionAlumno(asignacionId));

        request.setAttribute("asignacionAlumno", asignacionAlumno);
        request.getRequestDispatcher("asignacionAlumno/editar-asignacionAlumno.jsp").forward(request, response);
    }

    private void eliminarAsignacion(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String asignacionId = (request.getParameter("asignacionId"));
        AsignacionAlumno asignacion = new AsignacionAlumno(asignacionId);
        int registrosEliminados = new AsignacionAlumnoDaoImpl().eliminar(asignacion);
        System.out.println("Registros eliminados: " + registrosEliminados);
        listarAsignacion(request, response);
    }

    private void listarAsignacion(HttpServletRequest request, HttpServletResponse response) throws IOException {
        List<AsignacionAlumno> listaAsignacion = new AsignacionAlumnoDaoImpl().listar();

        HttpSession sesion = request.getSession();
        sesion.setAttribute("listadoAsignacion", listaAsignacion);
        sesion.setAttribute("numAsignacion", listaAsignacion.size());

        response.sendRedirect("asignacionAlumno/asignacionAlumno.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        request.setCharacterEncoding("UTF-8");
        String accion = request.getParameter("accion");

        if (accion != null) {
            switch (accion) {
                case "insertar":
                    insertarAsignacion(request, response);
                    break;
                case "actualizar":
                    actualizarAsignacion(request, response);
                    break;
            }
        }
    }

    private void insertarAsignacion(HttpServletRequest request, HttpServletResponse response) throws IOException {
        if (request.getParameter("asignacionId").equals("") || request.getParameter("carne").equals("") || request.getParameter("cursoId").equals("")
                || request.getParameter("fechaAsignacion").equals("")) {
            System.out.println("Campos Vacios");

        } else {
            String asignacionId = request.getParameter("asignacionId");
            String carne = request.getParameter("carne");
            int cursoId = Integer.parseInt(request.getParameter("cursoId"));
            Timestamp fechaAsignacion = Timestamp.valueOf(request.getParameter("fechaAsignacion"));

            AsignacionAlumno asignacionAlumno = new AsignacionAlumno(asignacionId, carne, cursoId, fechaAsignacion);
            int registrosInsertados = new AsignacionAlumnoDaoImpl().insertar(asignacionAlumno);
            System.out.println("Registros Insertados: " + registrosInsertados);
        }
        listarAsignacion(request, response);
    }

    private void actualizarAsignacion(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String asignacionId = request.getParameter("asignacionId");
        String carne = request.getParameter("carne");
        int cursoId = Integer.parseInt(request.getParameter("cursoId"));
        Timestamp fechaAsignacion = Timestamp.valueOf(request.getParameter("fechaAsignacion"));

        AsignacionAlumno asignacionAlumno = new AsignacionAlumno(asignacionId, carne, cursoId, fechaAsignacion);
        int registrosModificados = new AsignacionAlumnoDaoImpl().actualizar(asignacionAlumno);
        System.out.println("Registros Modificados: " + registrosModificados);
        listarAsignacion(request, response);
    }
}
