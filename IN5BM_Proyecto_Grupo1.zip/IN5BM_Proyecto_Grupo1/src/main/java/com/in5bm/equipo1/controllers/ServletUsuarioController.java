/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.in5bm.equipo1.controllers;

import java.io.IOException;
import java.util.List;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.annotation.WebServlet;
import javax.servlet.ServletException;

import com.in5bm.equipo1.models.domain.Usuario;
import com.in5bm.equipo1.models.dao.UsuarioDaoImpl;

/**
 *
 * @author Alejandro Javier García García Codigo Tecnico: IN5BM date 14/09/2021
 * time 16:37:40
 */
@WebServlet("/ServletUsuarioController")
public class ServletUsuarioController extends HttpServlet {

    Usuario usuario = new Usuario();
    UsuarioDaoImpl usuarioDaoImpl = new UsuarioDaoImpl();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

        String action = request.getParameter("action");

        if (action.equalsIgnoreCase("Ingresar")) {
            String user = request.getParameter("user");

            String pass = request.getParameter("pass");

            usuario = usuarioDaoImpl.validar(user, pass);
            if (usuario.getUser() != null) {
                request.setAttribute("usuario", usuario);
                request.getRequestDispatcher("inicio.jsp").forward(request, response);

            } else {
                request.getRequestDispatcher("index.jsp").forward(request, response);
            }
        } else {
            request.getRequestDispatcher("index.jsp").forward(request, response);

        }
    }

}
