/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.in5bm.equipo1.models.domain;

/**
 *
 * @author Carlos Josué Levy Aceituno Pocasangre
 * @date 30/08/2021
 * @time 09:40:36 AM
 *
 */
public class Salon {

    private int salonId;
    private int capacidad;
    private String descripcion;
    private String nombreSalon;

    public Salon() {
    }
    
    public Salon(int salonId) {
        this.salonId = salonId;
    }

    public Salon(int capacidad, String descripcion, String nombreSalon) {
        this.capacidad = capacidad;
        this.descripcion = descripcion;
        this.nombreSalon = nombreSalon;
    }

    public Salon(int salonId, int capacidad, String descripcion, String nombreSalon) {
        this.salonId = salonId;
        this.capacidad = capacidad;
        this.descripcion = descripcion;
        this.nombreSalon = nombreSalon;
    }

    public String getNombreSalon() {
        return nombreSalon;
    }

    public void setNombreSalon(String nombreSalon) {
        this.nombreSalon = nombreSalon;
    }

    public int getSalonId() {
        return salonId;
    }

    public void setSalonId(int salonId) {
        this.salonId = salonId;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return "Salon:"+salonId +" "+ capacidad +" "+ descripcion +" "+ nombreSalon;
    }
    
    
}