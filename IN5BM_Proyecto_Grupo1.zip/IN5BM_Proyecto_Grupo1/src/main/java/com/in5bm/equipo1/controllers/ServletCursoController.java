/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.in5bm.equipo1.controllers;

import com.in5bm.equipo1.models.dao.CursoDaoImpl;
import java.io.IOException;
import java.util.List;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest; //perticiones que son realizadas
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.annotation.WebServlet;
import javax.servlet.ServletException;

import com.in5bm.equipo1.models.domain.Curso;
import java.io.UnsupportedEncodingException;

/**
 *
 * @author Alejandro Javier García García Codigo Tecnico: IN5BM date 29/08/2021
 * time 16:37:40
 */
@WebServlet("/ServletCursoController")
public class ServletCursoController extends HttpServlet {

    private static final String JSP_LISTAR = "curso/curso.jsp";
    private static final String JSP_EDITAR = "curso/editar-curso.jsp";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        request.setCharacterEncoding("UTF-8");
        String accion = request.getParameter("accion");
        if (accion != null) {
            switch (accion) {
                case "listar":
                    listarCurso(request, response);
                    break;
                case "editar":
                    editarCurso(request, response);
                    break;
                case "eliminar":
                    eliminarCurso(request, response);
                    break;
            }
        }

    }

    public void editarCurso(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int cursoId = Integer.parseInt(request.getParameter("cursoId")); //revisar con el formulario de editar
        Curso curso = new CursoDaoImpl().encontrar(new Curso(cursoId));
        request.setAttribute("curso", curso);
        request.getRequestDispatcher(JSP_EDITAR).forward(request, response);
    }

    private void listarCurso(HttpServletRequest request, HttpServletResponse response) throws IOException {
        List<Curso> listaCurso = new CursoDaoImpl().listar();
        HttpSession sesion = request.getSession();
        sesion.setAttribute("listadoCurso", listaCurso);
        sesion.setAttribute("numCursos", listaCurso.size());

        response.sendRedirect(JSP_LISTAR);
    }

    private void eliminarCurso(HttpServletRequest request, HttpServletResponse response) throws IOException {

        int cursoId = Integer.parseInt(request.getParameter("cursoId"));

        Curso curso = new Curso(cursoId);

        int registrosEliminados = new CursoDaoImpl().eliminar(curso);

        System.out.println("Cantidad de registros eliminados: " + registrosEliminados);

        listarCurso(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        request.setCharacterEncoding("UTF-8");
        String accion = request.getParameter("accion");
        if (accion != null) {
            switch (accion) {
                case "insertar":
                    insertarCurso(request, response);
                    break;
                case "actualizar":
                    actualizarCurso(request, response);
                    break;
            }
        }
    }

    public void insertarCurso(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int ciclo = Integer.parseInt(request.getParameter("ciclo"));
        int cupoMaximo = Integer.parseInt(request.getParameter("cupoMaximo"));
        int cupoMinimo = Integer.parseInt(request.getParameter("cupoMinimo"));
        String descripcion = request.getParameter("descripcion");
        String codigoCarrera = request.getParameter("codigoCarrera");
        int horarioId = Integer.parseInt(request.getParameter("horarioId"));
        int instructorId = Integer.parseInt(request.getParameter("instructorId"));
        int salonId = Integer.parseInt(request.getParameter("salonId"));

        Curso curso = new Curso(ciclo, cupoMaximo, cupoMinimo, descripcion, codigoCarrera, horarioId, instructorId, salonId);
        int registrosInsertados = new CursoDaoImpl().insertar(curso);
        listarCurso(request, response);
    }

    public void actualizarCurso(HttpServletRequest request, HttpServletResponse response) throws IOException {
        System.out.println("ingrso actualizar");
        int cursoId = Integer.parseInt(request.getParameter("cursoId"));
        int ciclo = Integer.parseInt(request.getParameter("ciclo"));
        int cupoMaximo = Integer.parseInt(request.getParameter("cupoMaximo"));
        int cupoMinimo = Integer.parseInt(request.getParameter("cupoMinimo"));
        String descripcion = request.getParameter("descripcion");
        String codigoCarrera = request.getParameter("codigoCarrera");
        int horarioId = Integer.parseInt(request.getParameter("horarioId"));
        int instructorId = Integer.parseInt(request.getParameter("instructorId"));
        int salonId = Integer.parseInt(request.getParameter("salonId"));

        Curso curso = new Curso(cursoId, ciclo, cupoMaximo, cupoMinimo, descripcion, codigoCarrera, horarioId, instructorId, salonId);
        System.out.println("actulizar" + curso);
        int registrosModificados = new CursoDaoImpl().actualizar(curso);
        listarCurso(request, response);
    }
}
